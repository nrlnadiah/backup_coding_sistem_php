<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>5 Brilliant</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<style type="text/css">
		body{
			background:url("smkfut.jpg");
			background-repeat: repeat-xy;
		}
	</style>
</head>
<body>
	<form class="box" action="loginpage.html" method="post">
		<h1><i>SMK FELDA ULU TEBRAU</i></h1>
		<marquee><i><strong><h1>5 Brilliant 2021</h1></strong></i></marquee>
		<input type="text" name="" placeholder="username">
		<input type="password" name="" placeholder="password">
		<input type="submit" name="" placeholder="login">
		
	</form>

</body>
</html>