<?php
require "koneksi.php";

if(isset($_GET['Tambah'])){
    $value_nama = $_GET['input_nama'];
    $value_kelas = $_GET['input_kelas'];

    $sql = "INSERT INTO table_crud (nama, kelas) VALUES ('$value_nama','$value_kelas')";
    $execute = mysqli_query($koneksi, $sql);

    if($execute){
      header("Location:create.php");
    } else {
      echo "ERROR TO CREATE DATA !";
   }
 }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Create PHP</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style type="text/css">
        body{
            background:url("smkfut.jpg");
            background-repeat: repeat-xy;
        }
    </style>
</head>
<body>
    <center>
         
    <form action="create.php" method="POST">
        <table width =20% border="3" style="background-color: white">
<tr>
       <h3>Tambah/Create data</h3>
        <hr>
</tr>
<tr>
       <td> <label>nama</label>
            <input type="text" name="input_nama">
        </td> 
</tr>           
<tr>
       <td> <label>kelas</label>
            <input type="text" name="input_kelas">
        </td>
</tr>        
</table>
        <center>
            <input type="submit" name="Tambah" value="Tambah">
        </center>   
        </form>
</center>
</body>
</html>