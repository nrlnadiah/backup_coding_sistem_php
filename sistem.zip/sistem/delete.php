<?php
require "koneksi.php";

$id  = $_GET['id'];//dari url yang ada value id
$sql = "DELETE FROM table_crud WHERE id='$id'";
$execute = mysqli_query($koneksi, $sql);

if($execute){
	header("location:read.php");//supaya kembali ke halaman utama read.php
} else{
	echo "ERROR TO DELETE!";
}
?>