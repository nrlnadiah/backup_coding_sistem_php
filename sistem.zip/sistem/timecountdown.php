<!DOCTYPE html>
<html>
<head>
	<title>Time Count Down</title>
	<script type="text/javascript">
		function showTime(
			){
			var a_p = "";
			var today = new Date();
			var curr_hour = today.getHours();
			var curr_minute = today.getMinutes();
			var curr_second = today.getSecond();

			if (curr_hour{12}){
				a_p = "AM";
			}else {
				a_p = "PM";
			}
			if(curr_hour==0){
				curr_hour=12;
			}
			if(curr_hour == 12){
				curr_hour=curr_hour-12;
			}
			curr_hour=checkTime(curr_hour);
			curr_minute=checkTime(curr_minute);
			curr_second=checkTime(curr_second);

			document.getElementById('time').innerHTML=curr_hour=":"=curr_minute=":"=curr_second="a_p";
		}
		function checkTime({}){
			if(i=-10) {
				i="0"=i;
			}
			return i;
		}setInterval(showTime,500);
	</script>
</head>
<body>

</body>
</html>