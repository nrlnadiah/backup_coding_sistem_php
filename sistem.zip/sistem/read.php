<?php
 require "koneksi.php";
$sql     = "SELECT * FROM table_crud";
$execute = mysqli_query($koneksi,$sql);

?>
<!DOCTYPE html>
<html>
<head>
  <title>Read PHP</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <style type="text/css">
    body{
      background:url("smkfut.jpg");
      background-repeat: repeat-xy;
    }
  </style>
</head>
<body>
  <a href="create.php">Tambah.php</a>
   <center>
  <table width =60% border="3" style="background-color: white">
    <thead>
      <th>id</th>
      <th>nama</th>
      <th>kelas</th>
      <th>aksi</th>
    </thead>
    <?php while($result = mysqli_fetch_assoc($execute)){  ?>
    <tr>
      <td><?= $result['id']?></td>
      <td><?= $result['nama']?></td>
      <td><?= $result['kelas']?></td>
      <td>
        <a href="update.php?id=<?= $result['id']?>">Update</a>
        |
        <a href="delete.php?id=<?= $result['id']?>">Delete</a>
      </td>
    </tr>
  <?php } ?>
  </table>
</center>
</body>
</html> 